
  cordova.define('cordova/plugin_list', function(require, exports, module) {
    module.exports = [
      {
          "id": "cordova-plugin-startapp-ads.StartAppAds",
          "file": "plugins/cordova-plugin-startapp-ads/www/startappads.js",
          "pluginId": "cordova-plugin-startapp-ads",
        "clobbers": [
          "StartAppAds"
        ],
        "runs": true
        },
      {
          "id": "cordova-plugin-unityads.unityads",
          "file": "plugins/cordova-plugin-unityads/www/cordova-plugin-unityads.js",
          "pluginId": "cordova-plugin-unityads",
        "clobbers": [
          "unityads"
        ]
        },
      {
          "id": "cordova-plugin-facebook-ads.FacebookAds",
          "file": "plugins/cordova-plugin-facebook-ads/www/FacebookAds.js",
          "pluginId": "cordova-plugin-facebook-ads",
        "clobbers": [
          "window.FacebookAds"
        ]
        }
    ];
    module.exports.metadata =
    // TOP OF METADATA
    {
      "cordova-facebook-audience-network": "4.22.1",
      "cordova-plugin-extension": "1.6.0",
      "cordova-plugin-facebook-ads": "4.22.2",
      "cordova-plugin-startapp-ads": "1.1.0",
      "cordova-plugin-unityads": "0.1.0"
    };
    // BOTTOM OF METADATA
    });
    