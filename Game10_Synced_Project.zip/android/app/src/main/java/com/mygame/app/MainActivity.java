package com.mygame.app;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        registerPlugin(UnityAdsPlugin.class);
          registerPlugin(FacebookRewardedPlugin.class);
    }
}
